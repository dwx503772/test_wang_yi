<?php

define('IN_ECS', true);

include_once './includes/init.php';

dispatch($_POST);
?>