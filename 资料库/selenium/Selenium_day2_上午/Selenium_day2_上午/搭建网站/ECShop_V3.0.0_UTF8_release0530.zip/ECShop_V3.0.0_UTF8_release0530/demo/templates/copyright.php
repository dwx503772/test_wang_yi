<div style="padding: 0 10px">
    <div style="padding: 1em; border: 1px solid #BBDDE5; background: #f4fafb; text-align: center;">
    <?php echo $lang['copyright'];?>
    </div>
</div>