$(document).ready(function()
{
    $('.page a').addClass('loadInModal');
})
