<?php
$lang->contact->provider      = '所属供应商';
$lang->contact->providerName  = '供应商名称';
