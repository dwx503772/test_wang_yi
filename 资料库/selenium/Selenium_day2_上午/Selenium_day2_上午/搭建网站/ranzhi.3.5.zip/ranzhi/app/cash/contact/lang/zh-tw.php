<?php
$lang->contact->provider      = '所屬供應商';
$lang->contact->providerName  = '供應商名稱';
