$(document).ready(function()
{
    $('#original').change();
});
