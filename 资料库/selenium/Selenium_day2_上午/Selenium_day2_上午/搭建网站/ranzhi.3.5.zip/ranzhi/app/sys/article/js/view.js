$(document).ready(function()
{
    $('#commentBox').load( createLink('message', 'comment', 'objectType=article&objectID=' + v.articleID) ); 

    $('body').tooltip(
    {
        html: true,
        selector: "[data-toggle=tooltip]",
        container: "body"
    }); 
});
