<?php
$config->message = new stdclass();
$config->message->types = 'comment,message,notice,reply';

