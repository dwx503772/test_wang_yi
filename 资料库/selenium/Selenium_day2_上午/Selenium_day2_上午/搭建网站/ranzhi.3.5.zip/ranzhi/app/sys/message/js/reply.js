$(document).ready(function()
{   
    $.setAjaxForm('#replyForm', function(data)
    {
        if(data.result == 'success') setTimeout(function(){location.reload()}, 1500);
    }); 
});
