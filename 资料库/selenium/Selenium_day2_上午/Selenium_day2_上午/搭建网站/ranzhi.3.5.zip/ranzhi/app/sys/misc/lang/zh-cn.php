<?php
/**
 * The message module zh-cn file of ranzhi.
 *
 * @copyright   Copyright 2009-2015 青岛易软天创网络科技有限公司(QingDao Nature Easy Soft Network Technology Co,LTD, www.cnezsoft.com)
 * @license     ZPL (http://zpl.pub/page/zplv12.html)
 * @author      Hao Sun <sunhao@cnezsoft.com>
 * @package     message
 * @version     $Id$
 * @link        http://www.ranzhico.com
 */

if(!isset($lang->misc)) $lang->misc = new stdclass();
$lang->misc->version     = '版本%s';
$lang->misc->offcialSite = '官方网站';
$lang->misc->support     = '技术支持';
$lang->misc->userbook    = '用户手册';
$lang->misc->forum       = '论坛交流';
