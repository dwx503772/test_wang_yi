<?php
/**
 * The create view file of blog module of RanZhi.
 *
 * @copyright   Copyright 2009-2015 青岛易软天创网络科技有限公司(QingDao Nature Easy Soft Network Technology Co,LTD, www.cnezsoft.com)
 * @license     ZPL (http://zpl.pub/page/zplv12.html)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     blog
 * @version     $Id: create.html.php 9828 2014-06-09 05:27:02Z guanxiying $
 * @link        http://www.ranzhico.com
 */
?>
<?php include '../../../sys/article/view/create.html.php';?>
