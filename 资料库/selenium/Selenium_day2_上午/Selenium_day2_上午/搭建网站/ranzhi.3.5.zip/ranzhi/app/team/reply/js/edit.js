$(document).ready(function()
{
    $('.file-form .form-group div[class*=col-sm]').removeAttr('style');
    $("a[href*='forum']").parent().addClass('active');
    $("a[href*='forum'][href*='tree']").parent().removeClass('active');
    $("a[id*='board']").parent().removeClass('active');
    $("a[id='board" + v.boardID + "']").parent().addClass('active');
});
