DELETE FROM sys_lang WHERE `app`='team' AND `module`='user' AND `section`='roleList';

DELETE FROM sys_groupPriv WHERE `module` = 'user' AND `method` != 'colleague';
DELETE FROM sys_groupPriv WHERE `module` = 'search';
