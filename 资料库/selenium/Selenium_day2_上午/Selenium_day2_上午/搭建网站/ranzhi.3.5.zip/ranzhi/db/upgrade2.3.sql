alter TABLE `crm_customer` CHANGE `status` `status` enum('potential', 'intension', 'signed', 'payed', 'failed') NOT NULL default 'potential';
