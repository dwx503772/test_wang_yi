package com.hello;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by Linty on 9/4/2016.
 */
public class RanzhiTestCases {
    private WebDriver driver;
    private String baseUrl;

    /**
     * 测试用例前置条件
     */
    @Before
    public void setUp() {
        this.driver = new FirefoxDriver();
        this.baseUrl = "http://172.31.95.168:808/ranzhi/www";
        // sout + tab
        System.out.println("call setUp()");
    }

    /**
     * 测试用例清场操作
     */
    @After
    public void tearDown() {
        this.driver.quit();
        System.out.println("call tearDown()");
    }

    @Test
    public void testLogIn() {
        System.out.println("call testLogIn()");
        WebDriver driver = this.driver;

        driver.get(baseUrl);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.className("btn")).click();
        driver.findElement(By.linkText("简体")).click();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement account = driver.findElement(By.id("account"));
        account.clear();
        account.sendKeys("admin");

        WebElement password = driver.findElement(By.id("password"));
        password.clear();
        password.sendKeys("admin");

        driver.findElement(By.id("submit")).click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String expected = baseUrl + "/sys/index.html";
        String actual = driver.getCurrentUrl();
        Assert.assertEquals("登录页面跳转失败", expected, actual);


    }

    @Test
    public void testLogIn2() {
        System.out.println("call testLogIn2()");
        WebDriver driver = this.driver;
        driver.get(this.baseUrl);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.findElement(By.xpath("//div[@id=\"langs\"]/button")).click();
        driver.findElement(By.xpath("//*[@id=\"langs\"]/ul/li[1]/a")).click();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement account = driver.findElement(By.cssSelector("#account"));
        account.clear();
        account.sendKeys("admin");

        WebElement password = driver.findElement(By.cssSelector("#password"));
        password.clear();
        password.sendKeys("admin");

        driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        try {
            Thread.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String expected = baseUrl + "/sys/index.html";
        String actual = driver.getCurrentUrl();
        Assert.assertEquals("登录页面跳转失败", expected, actual);
    }
}
