# 引入unittest模组
import unittest
from time import sleep

from selenium import webdriver


# 继承unittest.TestCase基类
class RanzhiTestCases(unittest.TestCase):
    # define a method
    # 测试方法以test开头
    def test_log_in(self):
        print("call test_log_in()")
        driver = self.driver
        driver.get(self.base_url)
        sleep(2)

        # 改变语言为中文简体
        driver.find_element_by_class_name("btn").click()
        driver.find_element_by_link_text("简体").click()
        sleep(1)

        account = driver.find_element_by_id("account")
        account.clear()
        account.send_keys("admin")

        password = driver.find_element_by_id("password")
        password.clear()
        password.send_keys("admin")

        driver.find_element_by_id("submit").click()
        sleep(2)

        expected = self.base_url + "/sys/index.html"
        actual = driver.current_url
        # 断言
        self.assertEqual(expected, actual, "登录页面导航失败")



    def setUp(self):
        print("call setUp()")
        self.driver = webdriver.Firefox()
        self.base_url = "http://172.31.95.168:808/ranzhi/www"

    def tearDown(self):
        print("call tearDown()")
        self.driver.quit()

    def test_log_in2(self):
        print("call test_log_in2()")
        driver = self.driver
        driver.get(self.base_url)
        sleep(2)

        # 改变语言为中文简体
        driver.find_element_by_xpath("//div[@id='langs']/button").click()
        driver.find_element_by_xpath("//*[@id=\"langs\"]/ul/li[1]/a").click()
        sleep(1)

        account = driver.find_element_by_css_selector("#account")
        account.clear()
        account.send_keys("admin")

        password = driver.find_element_by_css_selector("#password")
        password.clear()
        password.send_keys("admin")

        driver.find_element_by_xpath("//*[@id=\"submit\"]").click()
        sleep(2)

        expected = self.base_url + "/sys/index.html"
        actual = driver.current_url
        # 断言
        self.assertEqual(expected, actual, "登录页面导航失败")
