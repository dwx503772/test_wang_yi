package com.hello;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by Linty on 9/11/2016.
 * RanzhiTestCase01: Selenium 模块化和数据驱动 基础示例1
 */
public class RanzhiTestCase01 {

    // 声明成员变量
    // 浏览器驱动，用来定位和操作页面元素 （Web Element）
    WebDriver driver;
    // 基础地址URL，用来在整个类 统一地址URL
    String baseUrl;

    @Before
    public void setUp(){
        this.driver = new FirefoxDriver();
        this.baseUrl = "http://localhost:808/ranzhi/www";
    }

    @After
    public void tearDown(){
        this.driver.quit();
    }

    @Test
    public void testLogIn() {
        // 声明局部变量，传递全局的driver给它进行操作
        WebDriver driver = this.driver;

        // 步骤1
        // 用局部变量driver 打开然之的登录地址
        openWebPage(driver, this.baseUrl);

        // 断言：检查是否打开了正确的登录地址
        Assert.assertEquals("登录页面打开错误",
                this.baseUrl + "/sys/user-login-L3JhbnpoaS93d3cvc3lzLw==.html",
                driver.getCurrentUrl());

        // 步骤2
        // 切换语言为中文
        changeChinese(driver);

        // 步骤3
        // 输入用户名 密码 进行登录
        logIn(driver, "admin", "admin");

        Assert.assertEquals("登录页面登录跳转失败",
                this.baseUrl + "/sys/index.html",
                driver.getCurrentUrl());

    }

    /**
     * 实际上的登录方法
     * @param driver：浏览器驱动
     * @param account：用户名
     * @param password：密码
     */
    private void logIn(WebDriver driver, String account, String password) {
        // 输入用户名
        WebElement accountElement = driver.findElement(By.id("account"));
        accountElement.clear();
        accountElement.sendKeys(account);

        // 输入密码
        WebElement passwordElement = driver.findElement(By.id("password"));
        passwordElement.clear();
        passwordElement.sendKeys(password);

        // 点击登录按钮
        driver.findElement(By.id("submit")).click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 切换为中文
     * @param driver：浏览器驱动
     */
    private void changeChinese(WebDriver driver) {
        // 步骤2
        // 点击 切换语言 复制出来的xpath //*[@id="langs"]/button
        driver.findElement(By.xpath("//div[@id=\"langs\"]/button")).click();

        // 点击 简体 复制出来的xpath //*[@id="langs"]/ul/li[1]/a
        // 但是我们可以用 link text
        driver.findElement(By.linkText("简体")).click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 模块化操作 1 ： 抽取打开页面的方法
     * @param driver: 浏览器驱动需要传进来
     * @param baseUrl： baseUrl也传递进来
     */
    private void openWebPage(WebDriver driver, String baseUrl) {
        driver.get(baseUrl);

        // 让java代码停止运行1秒钟，等待浏览器进一步响应
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
