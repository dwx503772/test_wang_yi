package com.hello;

import com.hello.library.RanzhiCommon;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created by Linty on 9/11/2016.
 * 使用模块化的测试用例
 */
public class RanzhiTestCase02 {

    // 成员变量
    private WebDriver driver;
    private String baseUrl;
    private RanzhiCommon common;

    @Before
    public void setUp() {
        this.driver = new FirefoxDriver();
        this.baseUrl = "http://172.31.95.220/ranzhi/www";
        this.common = new RanzhiCommon(this.driver, this.baseUrl);
    }

    @After
    public void tearDown() {

        this.driver.quit();
        this.common = null;
    }

    @Test
    public void testLoginWithModule() {
        WebDriver driver = this.driver;
        RanzhiCommon common = this.common;
        // 步骤一：打开页面
        common.openWebPage("/");
        Assert.assertEquals("登录页面打开错误",
                this.baseUrl + "/sys/index.php?m=user&f=login&referer=L3JhbnpoaS93d3cvc3lzL2luZGV4LnBocA==",
                driver.getCurrentUrl());

        // 步骤二：切换语言
        String actualLanguage = common.changeChinese();

        Assert.assertEquals("系统语言切换失败", "简体", actualLanguage);

        // 步骤三：进行登录
        common.logIn("admin", "123456");
        Assert.assertEquals("登录页面登录跳转失败",
                this.baseUrl + "/sys/index.php?m=index&f=index",
                driver.getCurrentUrl());

        // 步骤四：退出系统
        common.logOut();
        Assert.assertEquals("登录页面退出跳转失败",
                this.baseUrl + "/sys/index.php?m=user&f=login",
                driver.getCurrentUrl());
    }
}
