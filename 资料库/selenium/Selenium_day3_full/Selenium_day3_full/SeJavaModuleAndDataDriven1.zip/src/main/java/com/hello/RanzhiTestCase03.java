package com.hello;

import com.hello.library.RanzhiCommon;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/**
 * Created by Linty on 9/11/2016.
 * 使用了数据驱动，csv文件存储测试数据
 * 数据驱动不依赖第三个类。只需要用maven的类和本文件
 */
public class RanzhiTestCase03 {
    private WebDriver driver;
    private String baseUrl;
    private RanzhiCommon common;

    @Before
    /**
     * 测试用例执行前，预置条件。
     */
    public void setUp() {
        this.driver = new FirefoxDriver();
        this.baseUrl = "http://localhost:808/ranzhi/www";
        this.common = new RanzhiCommon(this.driver, this.baseUrl);
    }

    @After
    /**
     * 测试用例执行完，然后清场。
     */
    public void tearDown() {
        this.driver.quit();
        this.common = null;
    }

    @Test
    public void testLogInByCsv() {
        // 读取 csv 文件到FilerReader中
        // 用捕获异常的方式 进行文件读取，防止出现“文件不存在”的异常
        Reader reader = null;
        try {
            reader = new FileReader("src/main/resources/user_logins.csv");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // 读取 csv 到 records中
        Iterable<CSVRecord> records = null;
        try {
            if (reader != null) {
                records = CSVFormat.EXCEL.parse(reader);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (records != null) {
            for (CSVRecord loginRecord : records) {
                String accountToLogIn = loginRecord.get(0);
                String passwordToLogIn = loginRecord.get(1);

                WebDriver driver = this.driver;
                RanzhiCommon common = this.common;
                // 步骤一：打开页面
                common.openWebPage("/");
                Assert.assertEquals("登录页面打开错误",
                        this.baseUrl + "/sys/user-login-L3JhbnpoaS93d3cvc3lzLw==.html",
                        driver.getCurrentUrl());

                // 步骤二：切换语言
                String actualLanguage = common.changeChinese();

                Assert.assertEquals("系统语言切换失败", "简体", actualLanguage);

                // 步骤三：进行登录
                common.logIn(accountToLogIn, passwordToLogIn);
                Assert.assertEquals("登录页面登录跳转失败",
                        this.baseUrl + "/sys/index.html",
                        driver.getCurrentUrl());

                // 步骤四：退出系统
                common.logOut();
                Assert.assertEquals("登录页面退出跳转失败",
                        this.baseUrl + "/sys/user-login.html",
                        driver.getCurrentUrl());
            }
        }
    }
}
