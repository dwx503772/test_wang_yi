package com.hello.automation;

/**
 * Created by Linty on 8/19/2016.
 * Ranzhi App enums
 */
public enum RanzhiApp {
    /**
     * Ranzhi App Types (enums)
     */
    Crm,
    Oa,
    Cash,
    Team,
    Admin
}
