package com.hello.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;


/**
 * Created by Linty on 8/18/2016.
 * Common Library Class for Ranzhi Tests
 */
class RanzhiCommon {
    private String baseUrl;
    private WebDriver baseDriver;

    RanzhiCommon(String baseUrl, WebDriver baseDriver) {
        this.baseUrl = baseUrl;
        this.baseDriver = baseDriver;
    }

    void login(String account, String password) {
        WebDriver baseDriver = this.baseDriver;
        baseDriver.get(baseUrl);
        baseDriver.manage().window().maximize();
//        baseDriver.manage().window().setSize(new Dimension(800, 600));

        baseDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        baseDriver.findElement(By.id("account")).clear();
        baseDriver.findElement(By.id("account")).sendKeys(account);
        baseDriver.findElement(By.id("password")).clear();
        baseDriver.findElement(By.id("password")).sendKeys(password);
        baseDriver.findElement(By.id("submit")).click();
    }

    void addNewUser(RanzhiUser userToAdd) {
        WebDriver baseDriver = this.baseDriver;
        // 输入用户名
        WebElement userName = baseDriver.findElement(By.cssSelector("#account"));
        userName.clear();
        userName.sendKeys(userToAdd.getAccount());

        // 输入真实姓名
        WebElement realName = baseDriver.findElement(By.cssSelector("#realname"));
        realName.clear();
        realName.sendKeys(userToAdd.getName());

        // 输入性别
        if (userToAdd.getGender() == 'M') {
            baseDriver.findElement(By.cssSelector("#gender1")).click();
        } else if (userToAdd.getGender() == 'f') {
            baseDriver.findElement(By.cssSelector("#gender2")).click();
        }

        // 输入部门
        WebElement department = baseDriver.findElement(By.cssSelector("#dept"));
        Select departmentSelect = new Select(department);
        departmentSelect.selectByIndex(userToAdd.getDepartment());

        // 输入角色
        WebElement role = baseDriver.findElement(By.cssSelector("#role"));
        Select roleSelect = new Select(role);
        roleSelect.selectByIndex(userToAdd.getRole());

        // 输入密码
        WebElement password1 = baseDriver.findElement(By.cssSelector("#password1"));
        password1.clear();
        password1.sendKeys(userToAdd.getPassword());

        // 输入确认密码
        WebElement password2 = baseDriver.findElement(By.cssSelector("#password2"));
        password2.clear();
        password2.sendKeys(userToAdd.getPassword());

        // 输入邮箱
        WebElement email = baseDriver.findElement(By.cssSelector("#email"));
        email.clear();
        email.sendKeys(userToAdd.getEmail());

        // 提交
        baseDriver.findElement(By.cssSelector("#submit")).click();
        baseDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

    }

    void selectApp(RanzhiApp app) {
        WebDriver baseDriver = this.baseDriver;
        switch (app) {
            case Admin:
                baseDriver.findElement(By.cssSelector("#s-menu-superadmin > button")).click();
                break;
            case Crm:
                //TODO: add CRM app Selection
                break;
            case Cash:
                //TODO: add Cash app Selection
                break;
            case Team:
                //TODO: add Team app Selection
                break;
            case Oa:
                //TODO: add OA app Selection
                break;
        }
        baseDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
    }

    void selectSubMenuForAdmin(AdminSubMenu menu) {
        WebDriver baseDriver = this.baseDriver;
        switch (menu) {
            case Organization:
                baseDriver.findElement(
                        By.cssSelector("#mainNavbar > div.collapse.navbar-collapse > ul > li:nth-child(2) > a")).click();
                break;

            case Company:
                //TODO: add Company Selection
                break;

            case Permission:
                //TODO: add Permission Selection
                break;

            case Application:
                //TODO: add Application Selection
                break;

            case System:
                //TODO: add System Selection
                break;

            case Enhancement:
                //TODO: add Enhancement Selection
                break;
        }
    }

    void clickAddUserButton() {
        WebDriver baseDriver = this.baseDriver;
        baseDriver.findElement(
                By.cssSelector("body > div > div > div > div.col-md-2 > div > div.panel-body > a:nth-child(2)")).click();
    }

    void logout() {
        WebDriver baseDriver = this.baseDriver;
        baseDriver.findElement(By.id("start")).click();
        baseDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        baseDriver.findElement(By.linkText("退出")).click();
        baseDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
    }


}
