package com.hello.automation;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.*;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

/**
 * Created by Linty on 8/15/2016.
 * Ranzhi Tests
 */
public class RanzhiTestCase {

    private static WebDriver baseDriver;
    private static String baseUrl = "http://172.31.95.220/ranzhi/www/";
    private static RanzhiCommon baseRanzhiCommon;

    /**
     * setUp, 运行每一个测试之前需要运行的方法
     */
    @Before
    public void setUp() {
        System.out.println("@TestBefore: setUp()");
    }

    /**
     * setUpClass 运行每一个测试类之前需要运行的方法
     */
    @BeforeClass
    public static void setUpClass() {
        System.out.println("@BeforeClass: setUpClass()");
        baseDriver = new FirefoxDriver();
        baseRanzhiCommon = new RanzhiCommon(baseUrl, baseDriver);

        try {
            sleep(2000);
        } catch (InterruptedException ignored) {
        }
    }

    /**
     * tearDown，运行每一个测试之后需要运行的方法
     */
    @After
    public void tearDown() {
        System.out.println("@TestAfter: tearDown()");
    }

    /**
     * tearDownClass，运行每一个测试类之后需要运行的方法
     */
    @AfterClass
    public static void tearDownClass() {
        System.out.println("@AfterClass: tearDownClass()");
        if (baseDriver != null) {
            baseDriver.close();
        }
    }

    /**
     * 测试登录
     */
    @Test
    public void testLogin() {
        baseRanzhiCommon.login("admin", "123456");

        try {
            sleep(2000);
        } catch (InterruptedException ignored) {
        }
        String expected = baseUrl + "sys/index.php?m=index&f=index";
        // 断言
        Assert.assertEquals("登录跳转失败", expected, baseDriver.getCurrentUrl());
    }

    /**
     * 批量添加用户
     */
    @Test
    public void testAddBatchUserByCsv() {

        // 读取 csv 文件到FilerReader中
        // 用捕获异常的方式 进行文件读取，防止出现“文件不存在”的异常
        Reader in = null;
        try {
            in = new FileReader("src/main/resources/team_member.csv");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // 读取 csv 到 records中
        Iterable<CSVRecord> records = null;
        try {
            records = CSVFormat.EXCEL.parse(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 遍历 records，循环添加 userToAdd
        for (CSVRecord record : records) {
            RanzhiUser userToAdd = new RanzhiUser(
                    record.get(0), record.get(1),
                    Integer.parseInt(record.get(3)),
                    Integer.parseInt(record.get(4)),
                    record.get(2).toCharArray()[0],
                    record.get(5),
                    record.get(0) + record.get(6)
            );

            baseRanzhiCommon.login("admin", "123456");
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            String expectedMainUrl = baseUrl + "sys/index.php?m=index&f=index";
            Assert.assertEquals("登录成功主页跳转失败", expectedMainUrl, baseDriver.getCurrentUrl());

            baseRanzhiCommon.selectApp(RanzhiApp.Admin);
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            String expectedAdminUrl = baseUrl + "sys/index.php?m=admin&f=index";
            Assert.assertEquals("后台管理主页跳转失败", expectedAdminUrl, baseDriver.getCurrentUrl());

            baseDriver.switchTo().frame("iframe-superadmin");
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseRanzhiCommon.selectSubMenuForAdmin(AdminSubMenu.Organization);
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            String expectedOrganizationUrl = baseUrl + "sys/index.php?m=user&f=admin";
            Assert.assertEquals("后台管理组织跳转失败", expectedOrganizationUrl, baseDriver.getCurrentUrl());

            baseRanzhiCommon.clickAddUserButton();
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            String expectedAddUserUrl = baseUrl + "sys/index.php?m=user&f=create";
            Assert.assertEquals("添加成员主页跳转失败", expectedAddUserUrl, baseDriver.getCurrentUrl());

            baseRanzhiCommon.addNewUser(userToAdd);
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            try {
                sleep(5000);
            } catch (InterruptedException ignored) {
            }
            String expectedUserSavedUrl = baseUrl + "sys/index.php?m=user&f=admin";
            Assert.assertEquals("用户保存跳转失败", expectedUserSavedUrl, baseDriver.getCurrentUrl());
            baseDriver.switchTo().defaultContent();

            baseRanzhiCommon.logout();
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            String expectedLogoutUrl = baseUrl + "sys/index.php?m=user&f=login";
            Assert.assertEquals("退出登录页面跳转错误", expectedLogoutUrl, baseDriver.getCurrentUrl());

            baseRanzhiCommon.login(userToAdd.getAccount(), userToAdd.getPassword());

            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String expectedMainUrl2 = baseUrl + "sys/index.php?m=index&f=index";
            Assert.assertEquals("登录成功主页跳转失败", expectedMainUrl2, baseDriver.getCurrentUrl());

            baseRanzhiCommon.logout();
            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            String expectedLogoutUrl2 = baseUrl + "sys/index.php?m=user&f=login";
            Assert.assertEquals("退出登录页面跳转错误", expectedLogoutUrl2, baseDriver.getCurrentUrl());

        }


    }

    @Test
    public void testAddBatchUserByDb() {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            Connection conn = null;
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost/test?" +
                        "user=root&password=");
            } catch (SQLException e) {
                e.printStackTrace();
            }

            stmt = conn.createStatement();
            String sql = "SELECT \n" +
                    "  `account`,\n" +
                    "  `realname`,\n" +
                    "  `gender`,\n" +
                    "  `dept`,\n" +
                    "  `role`,\n" +
                    "  `password`,\n" +
                    "  `email` \n" +
                    "FROM\n" +
                    "  `test`.`userlist` \n" +
                    "LIMIT 0, 1000 ;";
            rs = stmt.executeQuery(sql);

            // or alternatively, if you don't know ahead of time that
            // the query will be a SELECT...

            if (stmt.execute(sql)) {
                rs = stmt.getResultSet();
                System.out.println(rs.next());
            }
            if (rs != null) {
                while (rs.next()) {
                    RanzhiUser userToAdd = new RanzhiUser(
                            rs.getString("account"),
                            rs.getString("realname"),
                            Integer.parseInt(rs.getString("role")),
                            Integer.parseInt(rs.getString("dept")),
                            rs.getString("gender").toCharArray()[0],
                            rs.getString("password"),
                            rs.getString("account") + rs.getString("email")
                    );

                    baseRanzhiCommon.login("admin", "123456");
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                    String expectedMainUrl = baseUrl + "sys/index.php?m=index&f=index";
                    Assert.assertEquals("登录成功主页跳转失败", expectedMainUrl, baseDriver.getCurrentUrl());

                    baseRanzhiCommon.selectApp(RanzhiApp.Admin);
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                    String expectedAdminUrl = baseUrl + "sys/index.php?m=admin&f=index";
                    Assert.assertEquals("后台管理主页跳转失败", expectedAdminUrl, baseDriver.getCurrentUrl());

                    baseDriver.switchTo().frame("iframe-superadmin");
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                    baseRanzhiCommon.selectSubMenuForAdmin(AdminSubMenu.Organization);
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    String expectedOrganizationUrl = baseUrl + "sys/index.php?m=admin&f=index";
                    Assert.assertEquals("后台管理组织跳转失败", expectedOrganizationUrl, baseDriver.getCurrentUrl());

                    baseRanzhiCommon.clickAddUserButton();
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                    String expectedAddUserUrl = baseUrl + "sys/index.php?m=user&f=create";
                    Assert.assertEquals("添加成员主页跳转失败", expectedAddUserUrl, baseDriver.getCurrentUrl());

                    baseRanzhiCommon.addNewUser(userToAdd);
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                    try {
                        sleep(5000);
                    } catch (InterruptedException ignored) {
                    }
                    String expectedUserSavedUrl = baseUrl + "sys/index.php?m=user&f=admin";
                    Assert.assertEquals("用户保存跳转失败", expectedUserSavedUrl, baseDriver.getCurrentUrl());
                    baseDriver.switchTo().defaultContent();

                    baseRanzhiCommon.logout();
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                    String expectedLogoutUrl = baseUrl + "sys/index.php?m=user&f=login";
                    Assert.assertEquals("退出登录页面跳转错误", expectedLogoutUrl, baseDriver.getCurrentUrl());

                    baseRanzhiCommon.login(userToAdd.getAccount(), userToAdd.getPassword());

                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                    String expectedMainUrl2 = baseUrl + "sys/index.php?m=index&f=index";
                    Assert.assertEquals("登录成功主页跳转失败", expectedMainUrl2, baseDriver.getCurrentUrl());

                    baseRanzhiCommon.logout();
                    baseDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                    String expectedLogoutUrl2 = baseUrl + "sys/index.php?m=user&f=login";
                    Assert.assertEquals("退出登录页面跳转错误", expectedLogoutUrl2, baseDriver.getCurrentUrl());

                }
            }
            // Now do something with the ResultSet ....
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            // it is a good idea to release
            // resources in a finally{} block
            // in reverse-order of their creation
            // if they are no-longer needed

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {
                } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {
                } // ignore

                stmt = null;
            }
        }
    }
}
