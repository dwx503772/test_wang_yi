package com.hello.library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by Linty on 9/11/2016.
 * 模块化然之的基本功能和业务逻辑
 */
public class RanzhiCommon {
    private WebDriver driver;
    private String baseUrl;

    // 构造方法

    /**
     * 构造方法，在实例化该类的时候，必须传递WebDriver和BaseURl进来
     *
     * @param driver：需要进行操作的浏览器驱动
     * @param baseUrl：需要进行操作的页面地址
     */
    public RanzhiCommon(WebDriver driver, String baseUrl) {
        this.driver = driver;
        this.baseUrl = baseUrl;
    }

    /**
     * 实际上的登录方法
     *
     * @param account：用户名
     * @param password：密码
     */
    public void logIn(String account, String password) {
        WebDriver driver = this.driver;
        // 输入用户名
        WebElement accountElement = driver.findElement(By.id("account"));
        accountElement.clear();
        accountElement.sendKeys(account);

        // 输入密码
        WebElement passwordElement = driver.findElement(By.id("password"));
        passwordElement.clear();
        passwordElement.sendKeys(password);

        // 点击登录按钮
        driver.findElement(By.id("submit")).click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 将系统语言切换到中文
     *
     * @return : 返回已经切换到的系统语言
     */
    public String changeChinese() {
        WebDriver driver = this.driver;
        // 步骤2
        // 点击 切换语言 复制出来的xpath //*[@id="langs"]/button
        // 声明一个常量，来定义 选择语言的按钮的 xpath
        final String LANG_XPATH = "//div[@id=\"langs\"]/button";
        driver.findElement(By.xpath(LANG_XPATH)).click();

        // 点击 简体 复制出来的xpath //*[@id="langs"]/ul/li[1]/a
        // 但是我们可以用 link text
        driver.findElement(By.linkText("简体")).click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return driver.findElement(By.xpath(LANG_XPATH)).getText();
    }

    /**
     * 模块化操作 1 ： 抽取打开页面的方法
     *
     * @param url: 打开页面的url，需要配合baseUrl
     *             baseUrl + url
     */
    public void openWebPage(String url) {
        WebDriver driver = this.driver;

        driver.get(this.baseUrl + url);

        // 让java代码停止运行1秒钟，等待浏览器进一步响应
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 登出系统
     */
    public void logOut() {
        WebDriver driver = this.driver;
        driver.findElement(By.id("start")).click();
        driver.findElement(By.linkText("退出")).click();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
