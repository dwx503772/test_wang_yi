# 基础的模块化操作

## 项目操作步骤
1. 新建一个Maven的项目
2. 用已有的pom.xml覆盖
3. 新建一个java package，名字为 com.hello
4. 在新建的包里面，创建一个java class： RanzhiTestCase01
    - 该java class 使用自带的模块化进行操作（将方法抽取出来，放到类里面）
    - 该java class 的模块化不可以被别的类调用
5. 在新建的包里面，再创建一个java class：RanzhiTestCase02
    - 该java class 需要使用一个外部的模块化类进行操作
    - 在新建的包里面，新建一个library包
    - 在library里面，新建一个java class：RanzhiCommon
        - RanzhiCommon 需要设计构造方法，传递WebDriver和BaseUrl
        - RanzhiCommon 里面拥有然之的基础业务逻辑方法 比如 logIn等
        - RanzhiCommon 里面不可以有断言的逻辑
    - 在RanzhiTestCase02里面实例化RanzhiCommon，进行操作。

## 项目文件结构
- 所有代码都在 src/main/java里面
- RanzhiTestCase01.java: 一个简单的模块化操作写的用例，不依赖别的类
- RanzhiTestCase02.java: 一个标准的带有第三方类的模块化操作写的用例，需要依赖第三方类
- library/RanzhiCommon.java: 一个模块化然之的方法示例
- library/CsvUtility.java: 一个处理Csv的类
- RanzhiTestCase03.java: 一个用数据驱动的用例，简单的csv，不需要用给第三个类
- RanzhiTestCase02.java: 数据驱动的复杂的用例，用csv，并且需要用第三个类 CsvUtility