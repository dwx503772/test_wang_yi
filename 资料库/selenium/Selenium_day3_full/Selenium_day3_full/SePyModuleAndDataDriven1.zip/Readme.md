# 基础的模块化操作

## 项目操作步骤
1. 新建一个Python的项目
2. 新建一个python package，名字为 com.hello
4. 在新建的包里面，创建一个python file： ranzhi_testcase_01.py
    - 创建一个class：RanzhiTestCase01
    - 该 class 使用自带的模块化进行操作（将方法抽取出来，放到类里面）
    - 该 class 的模块化不可以被别的类调用
5. 在新建的包里面，再创建一个python file：ranzhi_testcase_02.py
    - 该 class 需要使用一个外部的模块化类进行操作
    - 在新建的包里面，新建一个library包
    - 在library里面，新建一个python file：ranzhi_common.py
        - RanzhiCommon 需要设计构造方法，传递WebDriver和BaseUrl
        - RanzhiCommon 里面拥有然之的基础业务逻辑方法 比如 log_in等
        - RanzhiCommon 里面不可以有断言的逻辑
    - 在RanzhiTestCase02里面实例化RanzhiCommon，进行操作。

## 项目文件结构
- 所有代码都在 com/hello里面
- ranzhi_testcase_01.py: 一个简单的模块化操作写的用例，不依赖别的类
- ranzhi_testcase_02.py: 一个标准的带有第三方类的模块化操作写的用例，需要依赖第三方类
- library/ranzhi_common.py: 一个模块化然之的方法示例
- ranzhi_testcase_03.py: 一个用csv做数据驱动的测试用例
- ranzhi_testcase_04.py: 一个用csv做数据驱动的测试用例，比较复杂，用到的iframe和python的dict字典类型