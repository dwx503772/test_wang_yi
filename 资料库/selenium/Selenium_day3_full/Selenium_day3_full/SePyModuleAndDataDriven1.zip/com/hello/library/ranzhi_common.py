from time import sleep

from selenium import webdriver

"""
模块化然之的基本功能和业务逻辑
"""


class RanzhiCommon(object):
    """
    构造方法
    在实例化该类的时候，必须传递WebDriver和BaseURl进来
    :param driver: 需要进行操作的浏览器驱动
    :param base_url:需要进行操作的页面地址
    """
    def __init__(self, driver: webdriver.Firefox, base_url):
        self.driver = driver
        self.base_url = base_url

    """
    抽取打开页面的方法
    :param url 打开页面的url，需要配合baseUrl
        baseUrl + url
    """
    def open_web_page(self, url):
        driver = self.driver
        driver.get(self.base_url + url)
        sleep(2)

    def change_chinese(self):
        driver = self.driver
        LANG_XPATH = "//div[@id=\"langs\"]/button"
        driver.find_element_by_xpath(LANG_XPATH).click()
        driver.find_element_by_link_text("简体").click()

        sleep(2)

        return driver.find_element_by_xpath(LANG_XPATH).text

    def log_in(self, account, password):
        driver = self.driver
        account_element = driver.find_element_by_id("account")
        account_element.clear()
        account_element.send_keys(account)

        password_element = driver.find_element_by_id("password")
        password_element.clear()
        password_element.send_keys(password)

        driver.find_element_by_id("submit").click()

        sleep(2)

    def log_out(self):
        driver = self.driver
        driver.find_element_by_id("start").click()
        sleep(1)
        driver.find_element_by_link_text("退出").click()
        sleep(2)
