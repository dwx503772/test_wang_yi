import unittest
from time import sleep

from selenium import webdriver

"""
Selenium 模块化和数据驱动 基础示例1
"""


def open_web_page(driver: webdriver.Firefox, base_url):
    driver.get(base_url)
    sleep(1)


def change_chinese(driver: webdriver.Firefox):
    LANG_XPATH = "//div[@id=\"langs\"]/button"
    driver.find_element_by_xpath(LANG_XPATH).click()
    driver.find_element_by_link_text("简体").click()

    sleep(1)

    return driver.find_element_by_xpath(LANG_XPATH).text


def log_in(driver: webdriver.Firefox, account, password):
    account_element = driver.find_element_by_id("account")
    account_element.clear()
    account_element.send_keys(account)

    password_element = driver.find_element_by_id("password")
    password_element.clear()
    password_element.send_keys(password)

    driver.find_element_by_id("submit").click()

    sleep(2)


class RanzhiTestCase01(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.base_url = "http://localhost:808/ranzhi/www"

    def tearDown(self):
        self.driver.quit()

    def test_log_in(self):
        ## 声明局部变量，传递全局的driver给它进行操作
        driver = self.driver

        ## 步骤一：打开页面
        open_web_page(driver, self.base_url)

        self.assertEqual(self.base_url + "/sys/user-login-L3JhbnpoaS93d3cvc3lzLw==.html",
                         driver.current_url,
                         "登录页面打开错误")

        ## 步骤二：切换简体中文
        actual_language = change_chinese(driver)

        self.assertEqual("简体", actual_language,
                         "系统语言切换失败")

        ## 步骤三：进行登录
        log_in(driver, "admin", "admin")

        self.assertEqual(self.base_url + "/sys/index.html",
                         driver.current_url,
                         "登录页面登录跳转失败")
