import unittest

from selenium import webdriver

from com.hello.library.ranzhi_common import RanzhiCommon


class RanzhiTestCase02(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.base_url = "http://172.31.95.220/ranzhi/www"
        self.common = RanzhiCommon(self.driver, self.base_url)

    def tearDown(self):
        self.driver.quit()
        self.common = None

    def test_log_in(self):
        ## 声明局部变量，传递全局的driver给它进行操作
        driver = self.driver
        common = self.common

        ## 步骤一：打开页面
        common.open_web_page("/")

        self.assertEqual(self.base_url + "/sys/index.php?m=user&f=login&referer=L3JhbnpoaS93d3cvc3lzL2luZGV4LnBocA==",
                         driver.current_url,
                         "登录页面打开错误")

        ## 步骤二：切换简体中文
        actual_language = common.change_chinese()

        self.assertEqual("简体", actual_language,
                         "系统语言切换失败")

        ## 步骤三：进行登录
        common.log_in("admin", "123456")

        self.assertEqual(self.base_url + "/sys/index.php?m=index&f=index",
                         driver.current_url,
                         "登录页面登录跳转失败")

        ## 步骤四：登出系统
        common.log_out()
        self.assertEqual(self.base_url + "/sys/index.php?m=user&f=login",
                         driver.current_url,
                         "登录页面登录跳转失败")
