import csv
import unittest

from selenium import webdriver

from com.hello.library.ranzhi_common import RanzhiCommon


class RanzhiTestCase03(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.base_url = "http://localhost:808/ranzhi/www"
        self.common = RanzhiCommon(self.driver, self.base_url)

    def tearDown(self):
        self.driver.quit()
        self.common = None

    def test_log_in_by_csv(self):
        records = csv.reader(open("user_logins.csv", 'r', -1, encoding="utf-8"))
        for login_record in records:
            account_to_log_in = login_record[0]
            password_to_log_in = login_record[1]

            ## 声明局部变量，传递全局的driver给它进行操作
            driver = self.driver
            common = self.common

            ## 步骤一：打开页面
            common.open_web_page("/")

            self.assertEqual(self.base_url + "/sys/user-login-L3JhbnpoaS93d3cvc3lzLw==.html",
                             driver.current_url,
                             "登录页面打开错误")

            ## 步骤二：切换简体中文
            actual_language = common.change_chinese()

            self.assertEqual("简体", actual_language,
                             "系统语言切换失败")

            ## 步骤三：进行登录
            common.log_in(account_to_log_in, password_to_log_in)

            self.assertEqual(self.base_url + "/sys/index.html",
                             driver.current_url,
                             "登录页面登录跳转失败")

            ## 步骤四：登出系统
            common.log_out()
            self.assertEqual(self.base_url + "/sys/user-login.html",
                             driver.current_url,
                             "登录页面登录跳转失败")
