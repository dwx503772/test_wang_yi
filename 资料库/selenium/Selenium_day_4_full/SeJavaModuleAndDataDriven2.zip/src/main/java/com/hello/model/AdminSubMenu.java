package com.hello.model;

/**
 * Created by Linty on 9/25/2016.
 * 枚举型 后台管理子目录
 */
public enum AdminSubMenu {
    Company,
    Organization,
    Permission,
    Application,
    System,
    Enhancement
}
