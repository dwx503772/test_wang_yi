from time import sleep


class RanzhiCommon():
    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url

    def log_in(self, user_name, password):
        driver = self.driver
        base_url = self.base_url
        driver.navigate(base_url)
        sleep(2)

        driver.click("x,//div[@id=\"langs\"]/button")
        driver.click("l,简体")
        sleep(2)

        driver.type("account", user_name)
        driver.type("password", password)

        driver.click("submit")
        sleep(3)

    def log_out(self):
        browser = self.driver
        browser.click("start")
        browser.implicitly_wait(20)
        browser.click_by_text("退出")
        sleep(1)
        browser.implicitly_wait(20)
