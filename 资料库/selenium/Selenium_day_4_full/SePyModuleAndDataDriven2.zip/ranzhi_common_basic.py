from time import sleep

from selenium.webdriver.support.select import Select


class RanzhiCommonBasic(object):
    """
    然之的公共类，不使用封装的类
    注意：这个类不使用封装，使用WebDriver
    """

    def __init__(self, browser, base_ranzhi_url):
        """
        :arg browser: 传递测试用例中的浏览器
        :arg base_ranzhi_url: 传递测试用例中然之的基础页面
        """
        self.browser = browser
        self.base_ranzhi_url = base_ranzhi_url

    def ranzhi_login(self, user_name, password):
        # 声明一个浏览器
        browser = self.browser

        # 打开然之的网站 进行登录
        browser.get(self.base_ranzhi_url)
        sleep(1)

        browser.find_element_by_xpath(
            "/html/body/div/div[1]/div[1]/div/div/button").click()
        browser.find_element_by_link_text('简体').click()
        sleep(1)
        browser.implicitly_wait(20)
        # 查找用户输入框元素，并赋值到新的变量中acc
        acc = browser.find_element_by_id("account")

        # 找到用户名输入框，清除已有的输入
        acc.clear()
        # 给用户名输入框 输入用户
        acc.send_keys(user_name)

        # 查找密码输入框，并且赋值到新的变量中 pwd
        pwd = browser.find_element_by_id("password")
        # 找到密码输入框，清除已有的密码
        pwd.clear()
        # 给密码输入框 输入密码
        pwd.send_keys(password)

        # 登录
        browser.find_element_by_id("submit").click()
        sleep(1)
        browser.implicitly_wait(20)

    def ranzhi_logout(self):
        browser = self.browser
        browser.find_element_by_id("start").click()
        browser.implicitly_wait(20)
        browser.find_element_by_link_text("退出").click()
        sleep(1)
        browser.implicitly_wait(20)

    def ranzhi_add_user(self, user_to_add):
        """
        添加一个然之的用户，并保存提交。
        :param user_to_add: 是一个字典类型
            需要有的字典的键如下：
            user_name
            real_name
            gender
            department
            role
            password
            email
        :return: 无
        """
        browser = self.browser
        # 输入用户名
        user_name = browser.find_element_by_css_selector('#account')
        user_name.clear()
        user_name.send_keys(user_to_add["user_name"])

        # 输入真实姓名
        real_name = browser.find_element_by_css_selector('#realname')
        real_name.clear()
        real_name.send_keys(user_to_add["real_name"])

        # 输入性别
        if user_to_add["gender"] == "m":
            browser.find_element_by_css_selector('#gender1').click()
        elif user_to_add["gender"] == "f":
            browser.find_element_by_css_selector('#gender2').click()

        # 输入部门
        department = browser.find_element_by_css_selector('#dept')
        department_select = Select(department)
        department_select.select_by_index(user_to_add["department"])

        # 输入角色
        role = browser.find_element_by_css_selector('#role')
        role_select = Select(role)
        role_select.select_by_index(user_to_add["role"])
        # 输入密码
        password1 = browser.find_element_by_css_selector('#password1')
        password1.clear()
        password1.send_keys(user_to_add["password"])

        # 输入确认密码
        password2 = browser.find_element_by_css_selector('#password2')
        password2.clear()
        password2.send_keys(user_to_add["password"])

        # 输入邮箱
        email = browser.find_element_by_css_selector('#email')
        email.clear()
        email.send_keys(user_to_add["email"])

        # 提交
        browser.find_element_by_css_selector('#submit').click()
        sleep(5)
        browser.implicitly_wait(20)
