import unittest
from time import sleep

from automate_driver import AutomateDriver
from ranzhi_common import RanzhiCommon


class RanzhiTestCases01(unittest.TestCase):
    def setUp(self):
        print("call setUp()")
        self.driver = AutomateDriver()
        self.base_url = "http://172.31.95.220/ranzhi/www"
        self.common = RanzhiCommon(self.driver, self.base_url)

    def tearDown(self):
        print("call tearDown()")
        driver = self.driver
        driver.quit_browser()

    def test_log_in5(self):
        print("call test_log_in5()")
        base_url = self.base_url
        driver = self.driver

        # 调用模块化的 RanzhiCommon 进行模块化 登录
        self.common.log_in("admin", "123456")

        expected = base_url + "/sys/index.php?m=index&f=index"
        actual = driver.get_url()

        # 断言 检查点
        self.assertEqual(expected, actual, "登录页面跳转失败")

    def test_log_in2(self):
        print("call test_log_in2")
        base_url = self.base_url
        driver = self.driver

        # 调用模块化的 RanzhiCommon 进行模块化 登录
        self.common.log_in("demo", "123456")

        expected = base_url + "/sys/index.php?m=index&f=index"
        actual = driver.get_url()

        # 断言 检查点
        self.assertEqual(expected, actual, "登录页面跳转失败")


if __name__ == "__main__":
    unittest.main()
