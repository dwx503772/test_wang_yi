# -*- coding: utf-8 -*-
"""
1.引入模组 单元测试框架 unittest
"""
import csv
import unittest
from time import sleep

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

from automate_driver import AutomateDriver
from ranzhi_common import RanzhiCommon

"""
定义一个类，RanzhiTestCases02
2. 继承了 unittest里面的 TestCase
"""


class RanzhiTestCases02(unittest.TestCase):
    def test_log_in_batch(self):
        """
        def define 定义方法
        3. 方法以test开头
        """
        """
        测试然之登录
        :return:
        """
        browser = self.browser

        user_login_list = csv.reader(open("user_login.csv"))
        for user in user_login_list:
            user_to_log_in = {"account": user[0],
                              "password": user[1]}

            self.ranzhi_common.log_in(
                user_to_log_in["account"], user_to_log_in["password"])
            sleep(2)
            # 断言
            # 先写期望值，再写实际的结果，最后写错误提示
            self.assertEqual(self.base_url + "/sys/index.php?m=index&f=index",
                             browser.get_url(),
                             "登录页面跳转错误")

            self.ranzhi_common.log_out()
            sleep(2)
            self.assertEqual(self.base_url + "/sys/index.php?m=user&f=login",
                             browser.get_url(),
                             "退出登录页面跳转错误")

    def setUp(self):
        """
        初始化测试用例，前置条件
        """
        self.browser = AutomateDriver()
        self.base_url = "http://172.31.95.220/ranzhi/www"

        self.ranzhi_common = RanzhiCommon(self.browser, self.base_url)

    def tearDown(self):
        """
        测试收尾工作，关闭浏览器
        """
        self.browser.quit_browser()
