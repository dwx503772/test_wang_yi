# -*- coding: utf-8 -*-
"""
1.引入模组 单元测试框架 unittest
"""
import csv
import unittest
from time import sleep

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select

from ranzhi_common_basic import RanzhiCommonBasic

"""
定义一个类，AutomateTest2
2. 继承了 unittest里面的 TestCase
"""


class RanzhiTestCases03(unittest.TestCase):
    """
    注意，此测试用例，只使用RanzhiCommonBasic

    """

    def test_ranzhi_login(self):
        """
        def define 定义方法
        3. 方法以test开头
        """
        """
        测试然之登录
        :return:
        """
        browser = self.browser
        self.ranzhi_common.ranzhi_login("admin", "123456")

        # 断言
        # 先写期望值，再写实际的结果，最后写错误提示
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=index&f=index",
                         browser.current_url,
                         "登录页面跳转错误")

        self.ranzhi_common.ranzhi_logout()

        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=login",
                         browser.current_url,
                         "退出登录页面跳转错误")

    def test_ranzhi_add_user(self):
        browser = self.browser
        # 用管理员账户登录然之
        self.ranzhi_common.ranzhi_login("admin", "123456")
        # 断言
        # 断言
        # 先写期望值，再写实际的结果，最后写错误提示
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=index&f=index",
                         browser.current_url,
                         "登录页面跳转错误")

        # 选择后台管理按钮
        browser.find_element_by_css_selector(
            '#s-menu-superadmin > button').click()
        sleep(1)
        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=admin&f=index",
                         browser.current_url,
                         "后台管理页面跳转失败")

        # 选择添加成员
        # ！！！注意，需要进入元素所在的iframe中去定位该元素
        browser.switch_to.frame("iframe-superadmin")
        browser.find_element_by_css_selector(
            '#shortcutBox > div > div:nth-child(1) > div > a').click()
        sleep(1)
        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=create",
                         browser.current_url,
                         "添加成员页面跳转失败")

        # 真正添加用户，写入数据库
        # 声明一个用户 用字典类型
        user_to_add = {
            "user_name": "demo903",
            "real_name": "DEMO USER 903",
            "gender": "f",
            "department": 1,
            "role": 15,
            "password": "123456",
            "email": "demo903@demo.com"
        }

        self.ranzhi_common.ranzhi_add_user(user_to_add)

        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=admin",
                         browser.current_url,
                         "用户保存跳转失败")

        # ！！！在使用完进入的iframe后，必须退出，到默认的iframe中
        browser.switch_to.default_content()

        # 退出管理员账户
        self.ranzhi_common.ranzhi_logout()

        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=login",
                         browser.current_url,
                         "退出登录页面跳转错误")

        # 登录新创建的用户
        self.ranzhi_common.ranzhi_login(user_to_add["user_name"], user_to_add["password"])
        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=index&f=index",
                         browser.current_url,
                         "登录页面跳转错误")

        # 退出新创建用户
        self.ranzhi_common.ranzhi_logout()

        # 断言
        self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=login",
                         browser.current_url,
                         "退出登录页面跳转错误")

    def test_ranzhi_batch_add_user(self):
        # 　读CSV文件，并且将读到的文件写入 user_list 变量中
        #   文件中有中文，需要用 encoding='utf-8'
        user_list = csv.reader(
            open("user_list_to_add.csv", 'r', -1,
                 encoding='utf-8'))
        for user_line in user_list:
            browser = self.browser
            # 用管理员账户登录然之
            self.ranzhi_common.ranzhi_login("admin", "123456")
            # 断言
            # 断言
            # 先写期望值，再写实际的结果，最后写错误提示
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=index&f=index",
                             browser.current_url,
                             "登录页面跳转错误")

            # 选择后台管理按钮
            browser.find_element_by_css_selector(
                '#s-menu-superadmin > button').click()
            sleep(2)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=admin&f=index",
                             browser.current_url,
                             "后台管理页面跳转失败")

            # 选择添加成员
            # ！！！注意，需要进入元素所在的iframe中去定位该元素
            browser.switch_to.frame("iframe-superadmin")
            browser.find_element_by_css_selector(
                '#shortcutBox > div > div:nth-child(1) > div > a').click()
            sleep(2)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=create",
                             browser.current_url,
                             "添加成员页面跳转失败")

            # 真正添加用户，写入数据库
            # 声明一个用户 用字典类型
            user_to_add = {
                "user_name": user_line[0],
                "real_name": user_line[1],
                "gender": user_line[2],
                "department": user_line[3],
                "role": user_line[4],
                "password": user_line[5],
                "email": user_line[6]
            }

            self.ranzhi_common.ranzhi_add_user(user_to_add)
            sleep(2)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=admin",
                             browser.current_url,
                             "用户保存跳转失败")
            browser.implicitly_wait(20)
            # ！！！在使用完进入的iframe后，必须退出，到默认的iframe中
            browser.switch_to.default_content()

            # 退出管理员账户
            self.ranzhi_common.ranzhi_logout()
            sleep(2)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=login",
                             browser.current_url,
                             "退出登录页面跳转错误")

            # 登录新创建的用户
            self.ranzhi_common.ranzhi_login(user_to_add["user_name"], user_to_add["password"])
            sleep(1)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=index&f=index",
                             browser.current_url,
                             "登录页面跳转错误")

            # 退出新创建用户
            self.ranzhi_common.ranzhi_logout()
            sleep(1)
            browser.implicitly_wait(20)
            # 断言
            self.assertEqual(self.base_ranzhi_url + "sys/index.php?m=user&f=login",
                             browser.current_url,
                             "退出登录页面跳转错误")

    def setUp(self):
        """
        初始化测试用例，前置条件
        """
        self.browser = webdriver.Firefox()
        self.base_ranzhi_url = "http://172.31.95.220/ranzhi/www/"
        self.ranzhi_common = RanzhiCommonBasic(self.browser, self.base_ranzhi_url)

    def tearDown(self):
        """
        测试收尾工作，关闭浏览器
        """
        self.browser.quit()
