import csv
import smtplib
import unittest
from email.header import Header
from email.mime.text import MIMEText

from HTMLTestRunner import HTMLTestRunner
from ranzhi_testcases_01 import RanzhiTestCases01
from ranzhi_testcases_02 import RanzhiTestCases02
from ranzhi_testcases_03 import RanzhiTestCases03


class RanzhiTestRunner():
    def run_tests(self):
        # 创建一个测试套件
        test_suite = unittest.TestSuite()
        # 在测试套件中添加需要运行的测试用例
        # 一个测试套件中可以添加多个测试用例
        test_suite.addTest(RanzhiTestCases01("test_log_in5"))
        test_suite.addTest(RanzhiTestCases01("test_log_in2"))
        test_suite.addTest(RanzhiTestCases01("test_log_in5"))

        # 创建一个文本测试运行器，运行刚刚创建的测试套件
        text_test_runner = unittest.TextTestRunner()
        text_test_runner.run(test_suite)

    def run_tests_pro(self):
        # 创建一个测试套件
        test_suite = unittest.TestSuite()
        # 读取一个csv文件，该文件中记录需要执行的测试用例名字
        testcase_list = csv.reader(open("test_cases.csv"))

        for case in testcase_list:

            # 声明一个字典类型的变量，记录测试用例的类型和名字
            testcase = {"type": case[0],
                        "name": case[1]}

            if testcase["type"] == 'ranzhi01':
                test_suite.addTest(RanzhiTestCases01(testcase["name"]))
            elif testcase["type"] == 'ranzhi02':
                test_suite.addTest(RanzhiTestCases02(testcase["name"]))
            elif testcase["type"] == 'ranzhi03':
                test_suite.addTest(RanzhiTestCases03(testcase["name"]))

        report = open("test_result.html", "wb")

        html_test_runner = HTMLTestRunner(report,
                                          title="然之协同办公系统自动化测试结果",
                                          description="详细的测试结果")

        html_test_runner.run(test_suite)
        report.close()

    def send_email(self, targetEmail):
        """
        发送邮件
        :param targetEmail:
        :return:
        """

        # 打开测试报告结果
        # r:read
        # b:binary
        f = open("./test_result.html", "rb")

        # 将测试结果放到邮件的主体中
        mail_body = f.read()
        # 关闭测试结果的文件
        f.close()

        # 声明一个邮件对象，用刚刚得到的邮件主体
        msg = MIMEText(mail_body, "html", "utf-8")
        # 设置邮件的主题
        msg["subject"] = Header("Selenium自动化测试结果", "utf-8")

        # 创建一个SMTP服务对象
        # simple message transfer protocol
        # 简单的消息转移协议
        smtpMail = smtplib.SMTP()

        # 连接SMTP的服务器
        smtpMail.connect("smtp.21cn.com")

        emailFrom = "selenium@21cn.com"
        password = "Welcome123"
        # 登录SMTP的服务器
        smtpMail.login(emailFrom, password)

        # 使用SMTP的服务器发送邮件
        smtpMail.sendmail(emailFrom, targetEmail, msg.as_string())

        # 退出SMTP对象
        smtpMail.quit()


if __name__ == "__main__":
    test_runner = RanzhiTestRunner()
    # test_runner.run_tests()
    test_runner.run_tests_pro()
    test_runner.send_email("liu.tingli@qq.com")
