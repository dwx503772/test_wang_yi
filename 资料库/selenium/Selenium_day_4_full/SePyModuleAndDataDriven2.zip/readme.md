# Python + Selenium 自动化测试解决方案示例

## 代码的结构
1. 封装的自定义驱动类
    - automate_driver.py: 封装了`Selenium Webdriver`的自定义驱动类。
2. 模块化的系统功能调用类
    - ranzhi_common.py: 模块化的然之系统功能调用，此类使用上一步的封装好的 automate_driver.py。
    - ranzhi_common_basic.py: 模块化的然之系统功能调用，不使用自定义驱动类。而使用WebDriver。
3. 自动化测试用例类
    - ranzhi_testcases_01.py: 自动化测试用例，使用了封装的自定义驱动和ranzhi_common类。
    - ranzhi_testcases_02.py: 自动化测试用例，使用了封装的自定义驱动和ranzhi_common类，并且使用了csv做批量登录(user_login.csv)。
    - ranzhi_testcases_03.py: 自动化测试用例，使用了WebDriver 和 ranzhi_common_basic类，使用csv批量添加用户(user_list_to_add.csv)。
4. 自动化测试运行器
    - ranzhi_testrunner.py：自动化测试运行器，可以建立测试套件，添加自动化测试用例。发Email等。使用了csv读取测试用例(test_cases.csv)。
5. 第三方的公共类，提供普通功能
    - HTMLTestRunner.py: 一个测试运行器的类。提供HTML格式的测试报告。
6. 生成的测试报告
    - test_result.html